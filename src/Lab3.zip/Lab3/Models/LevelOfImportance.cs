namespace Itmo.ObjectOrientedProgramming.Lab3.Models;

public enum LevelOfImportance
{
    LowImportance,
    MediumImportance,
    HighImportance,
}