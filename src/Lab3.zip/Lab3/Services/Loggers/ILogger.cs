using Itmo.ObjectOrientedProgramming.Lab3.Entities.Messages;

namespace Itmo.ObjectOrientedProgramming.Lab3.Services.Loggers;

public interface ILogger
{
    public void Log(string messageLog);
}