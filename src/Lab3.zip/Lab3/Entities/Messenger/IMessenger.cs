namespace Itmo.ObjectOrientedProgramming.Lab3.Entities.Messanger;

public interface IMessenger
{
    void PrintText(string textBody);
}